
function addition(){
    var number1=parseInt(document.getElementById('num1').value);
    var number2=parseInt(document.getElementById('num2').value);
    document.getElementById('result').innerHTML=number1+number2;
}
function subraction(){
    var number1=parseInt(document.getElementById('num1').value);
    var number2=parseInt(document.getElementById('num2').value);
    document.getElementById('result').innerHTML=number1-number2;
}
function multiplication(){
    var number1=parseInt(document.getElementById('num1').value);
    var number2=parseInt(document.getElementById('num2').value);
    document.getElementById('result').innerHTML=number1*number2;
}
function division(){
    var number1=parseInt(document.getElementById('num1').value);
    var number2=parseInt(document.getElementById('num2').value);
    document.getElementById('result').innerHTML=number1/number2;
}
function percentage(){
    var number1=parseInt(document.getElementById('num1').value);
    var number2=parseInt(document.getElementById('num2').value);
    document.getElementById('result').innerHTML=((number1/100)*number2);
}
